create view movieinfo(movieid, name, year, rating, length, country, agrestrict, date_added) as
SELECT movies.movieid,
       movies.name,
       movies.year,
       movies.rating,
       movies.length,
       movies.country,
       movies.agrestrict,
       movies.date_added
FROM movies;

alter table movieinfo
    owner to axu;

