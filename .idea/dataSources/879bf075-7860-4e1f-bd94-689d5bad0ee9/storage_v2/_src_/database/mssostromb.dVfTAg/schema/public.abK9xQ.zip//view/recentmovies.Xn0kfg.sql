create view recentmovies(movieid, name, year, rating, length, country, agrestrict, date_added) as
SELECT movies.movieid,
       movies.name,
       movies.year,
       movies.rating,
       movies.length,
       movies.country,
       movies.agrestrict,
       movies.date_added
FROM movies
WHERE movies.date_added >= date_trunc('week'::text, CURRENT_DATE::timestamp with time zone);

alter table recentmovies
    owner to ostromb;

